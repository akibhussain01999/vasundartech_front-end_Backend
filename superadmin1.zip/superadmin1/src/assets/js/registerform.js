$(document).ready(function () {
  var current_fs, next_fs, previous_fs; //fieldsets
  var opacity;

  $(".next").click(function () {
    current_fs = $(this).parent();
    next_fs = $(this).parent().next();

    //Add Class Active
    $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

    //show the next fieldset
    next_fs.show();
    //hide the current fieldset with style
    current_fs.animate(
      { opacity: 0 },
      {
        step: function (now) {
          // for making fielset appear animation
          opacity = 1 - now;

          current_fs.css({
            display: "none",
            position: "relative",
          });
          next_fs.css({ opacity: opacity });
        },
        duration: 600,
      }
    );
  });

  $(".previous").click(function () {
    current_fs = $(this).parent();
    previous_fs = $(this).parent().prev();

    //Remove class active
    $("#progressbar li")
      .eq($("fieldset").index(current_fs))
      .removeClass("active");

    //show the previous fieldset
    previous_fs.show();

    //hide the current fieldset with style
    current_fs.animate(
      { opacity: 0 },
      {
        step: function (now) {
          // for making fielset appear animation
          opacity = 1 - now;

          current_fs.css({
            display: "none",
            position: "relative",
          });
          previous_fs.css({ opacity: opacity });
        },
        duration: 600,
      }
    );
  });

  $(".radio-group .radio").click(function () {
    $(this).parent().find(".radio").removeClass("selected");
    $(this).addClass("selected");
  });

  $(".submit").click(function () {
    return false;
  });
});

//file upload code - 1//

function readURLdoc(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function (e) {
      $(".image-upload-wrap-1").hide();

      $(".file-upload-image-1").attr("src", e.target.result);
      $(".file-upload-content-1").show();

      $(".image-title").html(input.files[0].name);
    };

    reader.readAsDataURL(input.files[0]);
  } else {
    removeUpload();
  }
}

function removeUpload1() {
  $(".file-upload-input-1").replaceWith($(".file-upload-input").clone());
  $(".file-upload-content-1").hide();
  $(".image-upload-wrap-1").show();
}
$(".image-upload-wrap-1").bind("dragover", function () {
  $(".image-upload-wrap-1").addClass("image-dropping");
});
$(".image-upload-wrap-1").bind("dragleave", function () {
  $(".image-upload-wrap-1").removeClass("image-dropping");
});

//file upload code - 1//

function readURLdoc2(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function (e) {
      $(".image-upload-wrap-2").hide();

      $(".file-upload-image-2").attr("src", e.target.result);
      $(".file-upload-content-2").show();

      $(".image-title").html(input.files[0].name);
    };

    reader.readAsDataURL(input.files[0]);
  } else {
    removeUpload();
  }
}

function removeUpload2() {
  $(".file-upload-input-2").replaceWith($(".file-upload-input").clone());
  $(".file-upload-content-2").hide();
  $(".image-upload-wrap-2").show();
}
$(".image-upload-wrap-2").bind("dragover", function () {
  $(".image-upload-wrap-2").addClass("image-dropping");
});
$(".image-upload-wrap-2").bind("dragleave", function () {
  $(".image-upload-wrap-2").removeClass("image-dropping");
});

function readURLdoc3(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function (e) {
      $(".image-upload-wrap-3").hide();

      $(".file-upload-image-3").attr("src", e.target.result);
      $(".file-upload-content-3").show();

      $(".image-title").html(input.files[0].name);
    };

    reader.readAsDataURL(input.files[0]);
  } else {
    removeUpload();
  }
}

function removeUpload3() {
  $(".file-upload-input-3").replaceWith($(".file-upload-input").clone());
  $(".file-upload-content-3").hide();
  $(".image-upload-wrap-3").show();
}
$(".image-upload-wrap-3").bind("dragover", function () {
  $(".image-upload-wrap-3").addClass("image-dropping");
});
$(".image-upload-wrap-3").bind("dragleave", function () {
  $(".image-upload-wrap-3").removeClass("image-dropping");
});

//navbar//
$(document).ready(function () {
  $("body").bootstrapMaterialDesign();
});

// date picker code

$(function () {
  $("#datepicker")
    .datepicker({
      autoclose: true,
      todayHighlight: true,
    })
    .datepicker("update", new Date());
});

//date picker bootstrap

$("#datepicker").datepicker({
  uiLibrary: "bootstrap4",
});

setTimeout(function () { 
  
            // Closing the alert 
            $('#alert').alert('close'); 
        }, 5000);

