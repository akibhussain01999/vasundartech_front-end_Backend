import { TestBed } from '@angular/core/testing';

import { ConfirmationDialog.ServiceService } from './confirmation-dialog.service.service';

describe('ConfirmationDialog.ServiceService', () => {
  let service: ConfirmationDialog.ServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConfirmationDialog.ServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
