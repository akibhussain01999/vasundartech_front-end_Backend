import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { map } from "rxjs/operators";
import { observable, Observable } from 'rxjs';
import{Loginemployee} from './views/auth/new-login/new-login/loginemployee';
import {User} from '../app/./user.model';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {
  Page_no: string;
  
  logout() {
      throw new Error("Method not implemented.");
  }


  createUserWithEmailAndPassword: any;
  isLoggedIn: boolean | Observable<boolean> | Promise<boolean>;


  constructor(private http:HttpClient) { }

 httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };


 baseUrl: string = "/users";
  //  baseUrl2: string = "http://localhost:3000/users";

  register(body: any) {
    return this.http.post("http://127.0.0.1:3000/users/adduser", body, {
      observe: "body",
      headers: new HttpHeaders().append("Content-Type", "application/json")
    });
  }


  //Normal get data 
getuserinfo() : Observable<any> {
    return this.http
      .get<any>(this.baseUrl + '/getuserdata')
      .pipe(map(response => response.data));
  }


//get user info with pagination
// getuserinfo(Page_no) : Observable<any> {
//     return this.http
//       .get<any>(this.baseUrl+'getuserdata?Page_no=' + Page_no)
//       .pipe(map(response => response.data));
//   }




  getUserById(id: number): Observable<any> {
    return this.http.get<any>(this.baseUrl + '/getuserdataByid?id=' + id);
  }


  updateUser(user: User) {
    return this.http.put<User>(this.baseUrl + '/update', user,this.httpOptions);
  }

  
  
//  updateUser(user: User): Observable<User[]> {
//     return this.http.put<User[]>(this.baseUrl + user.id, user);
//   }


   deleteUser(id: number):Observable<any> {
    return this.http.delete<any>(this.baseUrl +'/delete?id=' +id);
  }


  // login(body: any) {
  //   return this.http.post("http://127.0.0.1:8088/user/login/validate", body, {
  //     observe: "body",
  //     headers: new HttpHeaders().append("Content-Type", "application/json")
  //   });
  // }


  // loginemployee(body: any) {
  //   return this.http.post("http://127.0.0.1:8088/user/login/validate", body, {
  //     observe: "body",
  //     headers: new HttpHeaders().append("Content-Type", "application/json")
  //   });
  // }

  //working code
 url="http://127.0.0.1:8088/";

    loginemployee(loginEmployee:Loginemployee):Observable<any> {
    return this.http.post(this.url+`user/login/validate`,loginEmployee)
  
  }

}


// password
// e0e31640