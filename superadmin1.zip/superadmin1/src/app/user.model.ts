export interface User{
   message(message: any);
   status: number;
   result(result: any);
   id: number;
   Name: string;
   city : string;
   Gender :string;
   Hobby : string;
   Email : string;
   Address : string;
}

