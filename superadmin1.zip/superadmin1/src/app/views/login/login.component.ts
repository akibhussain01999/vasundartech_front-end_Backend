import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: "login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent { }
