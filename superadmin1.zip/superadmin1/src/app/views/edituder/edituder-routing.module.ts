import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EdituserComponent } from './edituser/edituser.component';

const edituser: Routes = [
  {path:'',component:EdituserComponent},
];

@NgModule({
  imports: [RouterModule.forChild(edituser)],
  exports: [RouterModule]
})
export class EdituderRoutingModule { }
