import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { User } from '../../../user.model';
import { UserserviceService } from '../../../userservice.service';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent implements OnInit {
user: User;

  editForm: FormGroup;
  controls: any;
  sup:any;
  data: any;
  result: any;
 
  constructor(private formBuilder: FormBuilder,private router: Router, private userserviceService: UserserviceService) { }

  ngOnInit() {
    let userId = window.localStorage.getItem("editUserId");
    if(!userId) {
      alert("Invalid action.")
      this.router.navigate(['/clients']);
      return;
    }
    this.editForm  = this.formBuilder.group({
      id: [''],
      Name: ['', Validators.required],
      city: ['', Validators.required],
      Gender: ['', Validators.required],
      Hobby: ['', Validators.required],
      Email: ['', Validators.required],
      Address: ['', Validators.required],
    });
    this.userserviceService.getUserById(+userId)
      .subscribe( result => {
        this.result=result;
        console.log(this.result);
     
              // this.editForm.patchValue(result);
 this.editForm.get('id').setValue(this.result.data[0].id);             
this.editForm.get('Name').setValue(this.result.data[0].Name);
this.editForm.get('city').setValue(this.result.data[0].city);
this.editForm.get('Gender').setValue(this.result.data[0].Gender);
this.editForm.get('Hobby').setValue(this.result.data[0].Hobby);
this.editForm.get('Email').setValue(this.result.data[0].Email);
this.editForm.get('Address').setValue(this.result.data[0].Address); 
             console.log(this.editForm.get('Name').value);
      });

  }





  onSubmit() {
    this.userserviceService.updateUser(this.editForm.value)
  
      .pipe(first())
      .subscribe(
        data => {
          console.log(data);
          if(data.status === 200) {
            alert('User updated successfully.');
            this.router.navigate(['/clients']);
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });
      }
  }