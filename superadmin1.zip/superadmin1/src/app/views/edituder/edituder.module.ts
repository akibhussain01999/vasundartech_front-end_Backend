import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EdituderRoutingModule } from './edituder-routing.module';
import { EdituserComponent } from './edituser/edituser.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';


@NgModule({
  declarations: [EdituserComponent],
  imports: [
    CommonModule,
    EdituderRoutingModule,
    ReactiveFormsModule,
    FormsModule

  ]
})
export class EdituderModule { }
