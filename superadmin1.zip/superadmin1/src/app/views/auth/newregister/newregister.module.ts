import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NewregisterRoutingModule } from './newregister-routing.module';
import { NewRegisterComponent } from './new-register/new-register.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
//import { DlDateTimeDateModule, DlDateTimePickerModule } from 'angular-bootstrap-datetimepicker';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'; 



@NgModule({
  declarations: [NewRegisterComponent],
  imports: [
    CommonModule,
    NewregisterRoutingModule,
    ReactiveFormsModule,
     FormsModule,
     NgbModule
  ],
  exports:[ 
    NgbModule]
})
export class NewregisterModule { }
