import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { UserserviceService } from '../../../../userservice.service';
import { NgbDateStruct, NgbCalendar, NgbDatepicker } from '@ng-bootstrap/ng-bootstrap';
import { invalid } from '@angular/compiler/src/render3/view/util';


@Component({
  selector: 'app-new-register',
  templateUrl: './new-register.component.html',
  styleUrls: ['./new-register.component.css'],
  providers:[UserserviceService]
  
})
export class NewRegisterComponent implements OnInit {
  registerForm: FormGroup;

  //date picker
  model: NgbDateStruct;
  date: { year: number, month: number };
  @ViewChild('dp') dp: NgbDatepicker;

  //end
  


  constructor(private formBuilder: FormBuilder,private calendar: NgbCalendar) { }

  ngOnInit() {
      this.registerForm = this.formBuilder.group({
          firstName: ['', Validators.required],
          lastName: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
          password: ['', [Validators.required, Validators.minLength(6)]],
          cpassword: ['', [Validators.required, Validators.minLength(6)]],
          date:['',Validators.required],
          phno:['',Validators.required],
          phno2:['',Validators.required],
          color:['',Validators.required],

           add:['',Validators.required],
          add2:['',Validators.required],
          landmark:['',Validators.required],
          zipcode:['',Validators.required],
          city:['',Validators.required],
          state:['',Validators.required],
          GSTNO:['',Validators.required],
          file:['',Validators.required]

      });
  }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  onSubmit() {
      // stop here if form is invalid
      if (this.registerForm.invalid) {
           //return;
           console.log("invalid form");
      }
      console.log(JSON.stringify(this.registerForm.value));
      alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value))
  }


  //date picker code

  selectToday() {
    this.model = this.calendar.getToday();
  }

  setCurrent() {
    //Current Date
    this.dp.navigateTo()
  }
  setDate() {
    //Set specific date
    this.dp.navigateTo({ year: 2013, month: 2 });
  }

  navigateEvent(event) {
    this.date = event.next;
  }

//END

}

// export interface IAlert{
//   id:number;
//   type:string;
//   message:string;
// }
