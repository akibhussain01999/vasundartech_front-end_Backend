import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NewLoginRoutingModule } from './new-login-routing.module';
import { NewLoginComponent } from './new-login/new-login.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';




@NgModule({
  declarations: [NewLoginComponent],
  imports: [
    CommonModule,
    NewLoginRoutingModule,
    ReactiveFormsModule,
    FormsModule,
  ]
})
export class NewLoginModule { }
