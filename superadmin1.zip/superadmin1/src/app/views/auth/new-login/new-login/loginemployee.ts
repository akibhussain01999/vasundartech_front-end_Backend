export class Loginemployee {
    username:string;
    password:string;
}
