import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
} from "@angular/forms";
import { UserserviceService } from "../../../../userservice.service";
import { Loginemployee } from "./loginemployee";

@Component({
  selector: "app-new-login",
  templateUrl: "./new-login.component.html",
  styleUrls: ["./new-login.component.css"],
})
export class NewLoginComponent implements OnInit {
  loginForm: FormGroup;
  massage: string;
  Error = false;
  constructor(
    private router: Router,
    private user: UserserviceService,
    private formbuilder: FormBuilder
  ) {}
  // working code

  get f() {
    return this.loginForm.controls;
  }

  ngOnInit() {
    this.loginForm = this.formbuilder.group({
      username: ["", [Validators.required]],
      password: ["", [Validators.required]],
    });
  }

  // setFormState():void{
  // this.loginForm=this.formbuilder.group({
  //   username:['',[Validators.required]],
  //   password:['',[Validators.required]]

  // })

  // }

  onSubmit() {
    let login = this.loginForm.value;
    this.login(login);
  }

  login(loginEmployee: Loginemployee) {
    this.user.loginemployee(loginEmployee).subscribe((employee) => {
      debugger;
      var succ = employee;
      // if(succ){
      //   this.loginForm.reset();
      //   localStorage.setItem("Employee",JSON.stringify(succ));
      //   this.router.navigate(['/dashboard']);
      //   // this.Error=true;
      //   // this.massage="User ID/Password wrong";
      // }else{

      //   this.Error=true;
      //   this.massage="User ID/Password wrong";
      //   console.log(this.massage);
      // }

      if ((status = "NOT_FOUND")) {
        this.Error = true;
        this.massage = "User ID/Password wrong";
        console.log(this.massage);
        // this.Error=true;
        // this.massage="User ID/Password wrong";
      } else {
        this.loginForm.reset();
        localStorage.setItem("Employee", JSON.stringify(succ));
        this.router.navigate(["/dashboard"]);
      }
    });
  }
}

// sudo mysql -u root
// SET PASSWORD FOR 'root'@'localhost' = PASSWORD('yourpassword');
// CREATE USER 'root1'@'localhost' IDENTIFIED BY 'password';
// GRANT ALL PRIVILEGES ON * . * TO 'newuser'@'localhost';
// FLUSH PRIVILEGES;
