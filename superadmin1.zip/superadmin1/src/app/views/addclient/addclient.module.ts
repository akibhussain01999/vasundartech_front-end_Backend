import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AddclientRoutingModule } from './addclient-routing.module';
import { AddclientregisterComponent } from './addclientregister/addclientregister.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'; 
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import {FileSelectDirective} from "ng2-file-upload";


@NgModule({
  declarations: [AddclientregisterComponent],
  imports: [
    CommonModule,
    AddclientRoutingModule,
    ReactiveFormsModule,
     FormsModule,
     NgbModule,
     
  ],
  exports:[ 
    NgbModule]
})
export class AddclientModule { }
