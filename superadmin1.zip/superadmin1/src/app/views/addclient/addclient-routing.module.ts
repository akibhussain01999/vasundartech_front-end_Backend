import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddclientregisterComponent } from './addclientregister/addclientregister.component';


const addclientroutes: Routes = [
  {
    path:'', component:AddclientregisterComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(addclientroutes)],
  exports: [RouterModule]
})
export class AddclientRoutingModule { }
