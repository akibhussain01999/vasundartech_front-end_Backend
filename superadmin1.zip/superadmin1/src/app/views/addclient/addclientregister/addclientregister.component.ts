import {
  Component,
  OnInit,
  ViewChild,
  Input,
  Output,
  EventEmitter,
  ElementRef,
} from "@angular/core";
import { UserserviceService } from "../../../userservice.service";
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl,
} from "@angular/forms";
import {
  NgbDatepicker,
  NgbDateStruct,
  NgbCalendar,
} from "@ng-bootstrap/ng-bootstrap";
import { HttpClient } from "@angular/common/http";
import { FileUploader } from "ng2-file-upload";

@Component({
  selector: "app-addclientregister",
  templateUrl: "./addclientregister.component.html",
  styleUrls: ["./addclientregister.component.css"],
})
export class AddclientregisterComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  massage: string;
  Error = false;

  //date picker
  model: NgbDateStruct;
  date: { year: number; month: number };
  @ViewChild("dp") dp: NgbDatepicker;
  cd: any;
  router: any;
  _router: any;

  //end

  constructor(
    private formBuilder: FormBuilder,
    private calendar: NgbCalendar,
    private userserviceService: UserserviceService
  ) {}

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      profile: ["", Validators.required],
      cname: ["", Validators.required],
      bname: ["", Validators.required],
      PAN: ["", Validators.required],
      GST: ["", Validators.required],
      ClientPhone: ["", Validators.required],
      email: ["", [Validators.required, Validators.email]],
      PersonName: ["", Validators.required],
      DOA: ["", Validators.required],
      Phone: ["", Validators.required],
      ContactEmail: ["", Validators.required],
      Address: ["", Validators.required],
      Country: ["", Validators.required],
      state: ["", Validators.required],
      city: ["", Validators.required],
      Zip: ["", Validators.required],
      documentupload: ["", Validators.required],
      adharcard: ["", Validators.required],
      // pancard: ["", Validators.required],
      // email: ['', [Validators.required, Validators.email]],
      // password: ['', [Validators.required, Validators.minLength(6)]],
      // cpassword: ['', [Validators.required, Validators.minLength(6)]],
      // date:['',Validators.required],
      // phno:['',Validators.required],
      // phno2:['',Validators.required],
      // color:['',Validators.required],

      //  add:['',Validators.required],
      // add2:['',Validators.required],
      // landmark:['',Validators.required],
      // zipcode:['',Validators.required],
      // city:['',Validators.required],
      // state:['',Validators.required],
      // GSTNO:['',Validators.required],
      // file:['',Validators.required]
    });
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.registerForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.registerForm.invalid) {
      this.Error = true;
      this.massage = "OPPS ALL FIELD IS REQUIRED !";
      console.log("invalid form");
      return;
    }
    this.Error = true;
    this.massage = "USER REGISTRATION SUCCESSFULL!";
    console.log(this.massage);
    console.log(JSON.stringify(this.registerForm.value));
    //alert("SUCCESS!! :-)\n\n" + JSON.stringify(this.registerForm.value));
    //this.router.navigate(["/dashboard"]);
    this.userserviceService
      .register(JSON.stringify(this.registerForm.value))
      .subscribe((data) => {
        console.log(data);
        this._router.navigate(["/dashboard"]);
        (error) => console.error(error);
      });
  }

  //date picker code

  selectToday() {
    this.model = this.calendar.getToday();
  }

  setCurrent() {
    //Current Date
    this.dp.navigateTo();
  }
  setDate() {
    //Set specific date
    this.dp.navigateTo({ year: 2013, month: 2 });
  }

  navigateEvent(event) {
    this.date = event.next;
  }

  //END

  // myFiles:string [] = [];

  // myForm = new FormGroup({
  //  name: new FormControl('', [Validators.required, Validators.minLength(3)]),
  //  bname: new FormControl('', [Validators.required]),
  //  file: new FormControl('', [Validators.required])
  // });

  // constructor(private http: HttpClient) { }
  //   ngOnInit(): void {
  //     throw new Error("Method not implemented.");
  //   }

  // get f(){
  //  return this.myForm.controls;
  // }

  // onFileChange(event) {

  //      for (var i = 0; i < event.target.files.length; i++) {
  //          this.myFiles.push(event.target.files[i]);
  //      }
  // }

  // submit(){
  //  const formData = new FormData();

  //  for (var i = 0; i < this.myFiles.length; i++) {
  //    formData.append("file[]", this.myFiles[i]);
  //  }

  // //  this.http.post('http://localhost:8001/upload.php', formData)
  // //    .subscribe(res => {
  // //      console.log(res);
  //      alert ('Uploaded Successfully.');
  //   //  })
  // }
}
