import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddclientregisterComponent } from './addclientregister.component';

describe('AddclientregisterComponent', () => {
  let component: AddclientregisterComponent;
  let fixture: ComponentFixture<AddclientregisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddclientregisterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddclientregisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
