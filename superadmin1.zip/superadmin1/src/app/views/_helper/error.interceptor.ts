// import { Injectable } from '@angular/core';
// import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
// import { Observable, throwError, from } from 'rxjs';
// import { catchError } from 'rxjs/operators';

// import { UserserviceService } from '../../userservice.service'
// @Injectable()
// export class ErrorInterceptor implements HttpInterceptor {
//     constructor(private authenticationService: UserserviceService) {}

//     intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
//         return next.handle(request).pipe(catchError(err => {
//             if (err.status === 401) {
//                 // auto logout if 401 response returned from api
//                 this.authenticationService.logout();
//                 location.reload(true);
//             }import { Component, OnInit } from '@angular/core';

//             // @Component({
//             //   selector: 'app-alert-component',
//             //   templateUrl: './alert-component.component.html',
//             //   styleUrls: ['./alert-component.component.css']
//             // })
//             // export class AlertComponentComponent implements OnInit {
            
//             //   //private subscription: Subscription;
//             //     message: any;
            
//             //     constructor() { }
            
//             //     ngOnInit() {
//             //        // this.subscription = this.alertService.getMessage().subscribe(message => { 
//             //             this.message = message; 
//             //         });
//             //     }
            
//             //     ngOnDestroy() {
//             //         this.subscription.unsubscribe();
//             //     }
//             // }
            
//             const error = err.error.message || err.statusText;
//             return throwError(error);
//         }))
//     }
// }