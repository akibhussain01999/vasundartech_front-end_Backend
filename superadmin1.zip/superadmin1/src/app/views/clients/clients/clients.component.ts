import { UserserviceService } from './../../../userservice.service';
import { Component, OnInit } from '@angular/core';
import {User} from './../../../user.model';
import { Router } from '@angular/router';
import { ConfirmationDialogServiceService } from '../../../confirmation-dialog/confirmation-dialog-service.service'


@Component({
  selector: 'app-clients',
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.css'],
  providers:[ConfirmationDialogServiceService]
})
export class ClientsComponent implements OnInit {
debugger
   users: any;
  private _document: any;

  

  //  users: User[]= [];

  constructor(private router: Router,private userserviceService:UserserviceService,private confirmationDialogService: ConfirmationDialogServiceService) { }

//Page_no:number=0;

ngOnInit() {

     this.userserviceService.getuserinfo()
      .subscribe( data => {
          this.users = data;
          console.log(this.users)
      });


    

  }
// ***********************************************Edit user*******************************

 editUser(user: User): void {
    window.localStorage.removeItem("editUserId");
    window.localStorage.setItem("editUserId", user.id.toString());
    console.log(this.editUser)
    this.router.navigate(['/edituser']);
    console.log(['/edituser']);
  };



  


// **********************************Delete user info**********************************************************
   showMsg: boolean = false;
deleteUser(id: number) {
    if(this.showMsg= true) {
      this.userserviceService.deleteUser(id).subscribe(
        result => {
          console.log(result);
          if ( !result.error) {
          
            this.users = this.users.filter(item => item.id != id)
            // window.location.reload();
            
          } else {
            alert('Some thingh went wrong!');
          }
        }
      )
    }
    }


  // public openConfirmationDialog() {
  //   this.confirmationDialogService.confirm('Please confirm..', 'Do you really want to ... ?')
  //   .then((confirmed) => console.log('User confirmed:', confirmed))
  //   .catch(() => console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)'));
  // }

}

