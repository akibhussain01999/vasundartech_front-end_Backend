import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClientsRoutingModule } from './clients-routing.module';
import { ClientsComponent } from './clients/clients.component';
import { ConfirmationDialogComponent } from '../../confirmation-dialog/confirmation-dialog.component';
import { ConfirmationDialogServiceService } from '../../confirmation-dialog/confirmation-dialog-service.service';


@NgModule({
  declarations: [ClientsComponent,ConfirmationDialogComponent],
  imports: [
    CommonModule,
    ClientsRoutingModule
  ],
  providers:[ConfirmationDialogServiceService]
})
export class ClientsModule { }
