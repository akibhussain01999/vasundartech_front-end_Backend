var pool = require("../lib/config");


//register user
var adduserdata = (
  Name,
  city,
  Gender,
  Hobby,
  Password,
  Email,
   Address
) => {
  return new Promise((resolve, reject) => {
    pool
      .query(
        'INSERT INTO userinfo1("Name","city","Gender","Hobby","Password","Email","Address")VALUES($1,$2,$3,$4,$5,$6,$7)',
        [Name,city,Gender,Hobby,Password,Email,Address]
      )
      .then((result) => {
        resolve(result.rows[0]);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

// //show user list

var getuserdatainfo = (Page_no) => {
  Page_size = 50;
  Page_start = Page_no * Page_size;
  return new Promise((resolve, reject) => {
    pool
      .query(
        'SELECT userinfo1.*,count(*) OVER() AS total_records from userinfo1 order by userinfo1."id" limit $1 offset $2',
        [Page_size, Page_start]
      )
      .then((result) => {
        console.log(result);
        resolve(result.rows[0]);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

// //show user list by id
var getuserdataByid = (id) => {
  return new Promise((resolve, reject) => {
    pool
      .query('select "un".* from userinfo1 un where id=$1', [id])
      .then((result) => {
        console.log(result);
        resolve(result.rows);
      })

      .catch((err) => {
        reject(err);
      });
  });
};

var updateuserlist = (id,Name,city,Gender,Hobby,Password,Email,Address) => {
  return new Promise((resolve, reject) => {
    pool
      .query(
        'update userinfo1  set "Name"=$1,"city"=$2,"Gender"=$3,"Hobby"=$4,"Password"=$5,"Email"=$6,"Address"=$7 where id= $8;',
        [Name,city,Gender,Hobby,Password,Email,Address,id]
      )
      .then((result) => {
        resolve(result.rows[0]);
      })
      .catch((err) => {
        reject(err);
      });
  });
};

// //delte user list

var deleteuser = (id) => {
  return new Promise((resolve, reject) => {
    pool
      .query("delete from userinfo1 where id=$1;", [id])
      .then((result) => {
        resolve(result.rows[0]);
      })
      .catch((err) => {
        reject(err);
      });
  });
};


var loginuser = (Email,Password) => {
  return new Promise((resolve, reject) => {

    email=result.rows[0].Email;
    pass=result.rows[0].Password;

    if(Email==email && Password==pass)
    {
    pool
      .query("select *from userinfo1 where email=$1,Password=$2;", [Email,Password])
      .then((result) => {
        resolve(result.rows[0]);
      })
      .catch((err) => {
        reject(err);
      });
    }else{
      res.status(400).json({ message: "User or email is wrong !"});
    
    }

  });
};


module.exports = {
  getuserdataByid: getuserdataByid,
  getuserdatainfo: getuserdatainfo,
  adduserdata: adduserdata,
  // IsuserExists: IsuserExists,
  updateuserlist: updateuserlist,
  deleteuser:deleteuser,
  loginuser:loginuser
  
};
